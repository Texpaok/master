<?php
/**
* Modelo Joommark
* @ author Jose A. Luque
* @ Copyright (c) 2011 - Jose A. Luque
* @license GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
*/

// Chequeamos si el archivo est� inclu�do en Joomla!
defined('_JEXEC') or die();
jimport( 'joomla.application.component.model' );


class JoommarksModelJoommark extends JModelLegacy
{

function __construct()
{
	parent::__construct();

	
}


}