DROP TABLE IF EXISTS `#__joommark_serverstats`;
DROP TABLE IF EXISTS `#__joommark_stats`;
DROP TABLE IF EXISTS `#__joommark_referral`;
DROP TABLE IF EXISTS `#__joommark_searches`;
DROP TABLE IF EXISTS `#__joommark_plansstats`;
DROP TABLE IF EXISTS `#__joommark_plansstats_track`;
DROP TABLE IF EXISTS `#__joommark_feedbacksstats`;
