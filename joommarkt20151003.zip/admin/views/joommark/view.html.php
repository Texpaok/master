<?php

/**
* @ author Jose A. Luque
* @ Copyright (c) 2011 - Jose A. Luque
* @license GNU/GPL v2 or later http://www.gnu.org/licenses/gpl-2.0.html
*/

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );

/**
 * Securitycheck View
   */
class JoommarksViewJoommark extends JViewLegacy
{
	/**
	 * M�todo display de la vista Joommark
	 **/
	function display($tpl = null)
	{
		
				
		parent::display($tpl);
	}
}